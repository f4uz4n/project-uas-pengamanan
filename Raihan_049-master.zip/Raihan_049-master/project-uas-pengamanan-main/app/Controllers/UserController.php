<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use CodeIgniter\Config\Services;

class UserController extends ResourceController
{
    protected $modelName = 'App\Models\UserModel';
    protected $format    = 'json';

    public function show($id = null)
    {
        $authHeader = $this->request->getHeaderLine('Authorization');
        $token = str_replace('Bearer ', '', $authHeader);

        try {
            $decoded = JWT::decode($token, new Key(getenv('JWT_SECRET'), 'HS256'));
        } catch (ExpiredException $e) {
            return Services::response()->setStatusCode(401)->setJSON(['message' => 'Token expired']);
        } catch (\Exception $e) {
            return Services::response()->setStatusCode(401)->setJSON(['message' => 'Invalid token']);
        }

        // Hanya tampilkan data jika user_id dalam token sesuai dengan id yang diminta
        if ($decoded->user_id != $id) {
            return Services::response()->setStatusCode(403)->setJSON(['message' => 'Unauthorized']);
        }

        $data = $this->model->find($id);
        if (!$data) {
            return $this->failNotFound('User not found');
        }

        return $this->respond($data);
    }

    public function update($id = null)
    {
        $authHeader = $this->request->getHeaderLine('Authorization');
        $token = str_replace('Bearer ', '', $authHeader);

        try {
            $decoded = JWT::decode($token, new Key(getenv('JWT_SECRET'), 'HS256'));
        } catch (ExpiredException $e) {
            return Services::response()->setStatusCode(401)->setJSON(['message' => 'Token expired']);
        } catch (\Exception $e) {
            return Services::response()->setStatusCode(401)->setJSON(['message' => 'Invalid token']);
        }

        // Cek apakah user yang login adalah user yang ingin diupdate
        if ($decoded->user_id != $id) {
            return Services::response()->setStatusCode(403)->setJSON(['message' => 'Unauthorized']);
        }

        $data = $this->request->getJSON();

        $this->model->update($id, [
            'username' => $data->username,
            'email' => $data->email,
        ]);

        return $this->respond(['message' => 'User updated successfully']);
    }
}
