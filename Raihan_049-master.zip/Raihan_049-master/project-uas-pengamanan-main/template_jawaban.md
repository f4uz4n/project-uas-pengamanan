# UAS Keamanan Komputer

## Identitas
- Nama:
- NIM:
- Kelas:
- Repo GitHub: [link]

---

## Bagian A – Bug Fixing JWT REST API

### Bug 1: Token tetap aktif setelah logout
**Penjelasan:**  
...

**Solusi:**  
...

---

## Bagian B – Simulasi Serangan dan Solusi

### Jenis Serangan: Broken Access Control  
**Simulasi Postman:**  
...

**Solusi Implementasi:**  
...

---

## Bagian C – Refleksi Teori & Etika

### 1. CIA Triad dalam Keamanan Informasi  
...

### 2. UU ITE yang relevan  
...

### 3. Pandangan Al-Qur'an  
- Surah Al-Baqarah: 205  
...

### 4. Etika Cyber dan Kejujuran  
...

