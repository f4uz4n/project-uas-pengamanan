# UAS Keamanan Komputer

## Identitas
- Nama:Achmad Raihan Ramadhan
- NIM:221080200049
- Kelas:6B1 Informatika
- Repo GitHub: [link]

---

## Bagian A – Bug Fixing JWT REST API

### Bug 1: Token tetap aktif setelah logout
**Penjelasan:**  
API tidak menyimpan token yang aktif (sessionless), sehingga saat logout tidak ada cara memverifikasi apakah token itu sudah "dicabut" atau tidak. Akibatnya, meskipun user sudah logout, token sebelumnya tetap bisa digunakan untuk mengakses endpoint.

**Solusi:**
Tambahkan token blacklist system atau simpan token yang aktif di database/Redis dan validasi token saat request masuk. Ketika user logout, hapus token dari daftar aktif.

**PHP**
// Contoh logika logout di CodeIgniter 4
public function logout()
{
    $token = $this->request->getHeaderLine('Authorization');
    if ($token) {
        $cleaned = str_replace('Bearer ', '', $token);
        // Simpan token ini ke tabel blacklist
        $this->tokenModel->blacklist($cleaned);
    }
    return $this->respond(['message' => 'Logout successful']);
}
--------------------------------------------------------------------------------------------------------------------------------------------------------
 Bug 2: Tidak ada pembatasan akses endpoint berdasarkan role
Penjelasan:
Semua endpoint bisa diakses oleh siapa saja yang memiliki token valid, tanpa memeriksa role user. Akibatnya, user biasa bisa mengakses endpoint admin.

**Solusi:**
Tambahkan pemeriksaan role user di middleware atau controller. Gunakan payload token (misalnya: role) untuk menentukan hak akses.

**PHP**
\
if ($user->role !== 'admin') {
    return $this->failForbidden('Access denied');
}
--------------------------------------------------------------------------------------------------------------------------------------------------------
Bug 3: User bisa mengakses data user lain hanya dengan ganti ID
Penjelasan:
Endpoint seperti GET /api/users/{id} atau PUT /api/users/{id} tidak mengecek apakah id tersebut adalah milik user yang sedang login. Akibatnya, user biasa bisa mengambil atau mengubah data user lain.

Solusi:
Validasi user_id dalam token dengan id di parameter request. Jika tidak cocok dan user bukan admin, blokir.

**PHP**
if ($requestedId !== $userIdFromToken && $role !== 'admin') {
    return $this->failForbidden('Not allowed to access other user data');
}
--------------------------------------------------------------------------------------------------------------------------------------------------------
## Bagian B – Simulasi Serangan dan Solusi

### Jenis Serangan: Broken Access Control
Penjelasan:
Serangan terjadi karena tidak adanya pembatasan akses berdasarkan identitas pengguna. Ini memungkinkan user biasa mengubah data user lain (termasuk admin) dengan memanipulasi user_id di body request. Ini merupakan Broken Object Level Authorization (BOLA).
**Simulasi Postman:**  
// Endpoint: PUT /api/users/update
{
  "user_id": 1,   // ID Admin
  "name": "Hacked Admin",
  "email": "hacked@admin.com"
}
--------------------------------------------------------------------------------------------------------------------------------------------------------

**Solusi Implementasi:**  
Middleware/Filter Akses
Langkah:

Tambahkan middleware atau filter yang membaca payload JWT.

Cocokkan user_id di body/param dengan user_id di token.

Jika tidak cocok dan bukan admin, tolak permintaan.

Contoh Kode Middleware (CodeIgniter 4):

php
public function before(RequestInterface $request, $arguments = null)
{
    $token = $request->getHeaderLine('Authorization');
    $decoded = JWT::decode($token, new Key(SECRET_KEY, 'HS256'));
    
    $requestBody = json_decode($request->getBody(), true);
    $requestUserId = $requestBody['user_id'] ?? null;

    if ($decoded->role !== 'admin' && $decoded->user_id != $requestUserId) {
        return Services::response()
            ->setStatusCode(403)
            ->setJSON(['message' => 'Forbidden']);
    }
}
--------------------------------------------------------------------------------------------------------------------------------------------------------
## Bagian C – Refleksi Teori & Etika

### 1. CIA Triad dalam Keamanan Informasi  
CIA Triad adalah tiga prinsip dasar dalam keamanan informasi:

Confidentiality (Kerahasiaan): Menjaga agar informasi hanya dapat diakses oleh pihak yang berwenang. Misalnya, penggunaan enkripsi dan autentikasi.

Integrity (Integritas): Memastikan bahwa informasi tidak diubah atau dimodifikasi oleh pihak yang tidak berwenang. Contohnya dengan checksum, hashing, dan kontrol akses.

Availability (Ketersediaan): Informasi harus selalu tersedia ketika dibutuhkan oleh pihak yang berwenang. Ini bisa dijaga melalui backup data, server redundancy, dan proteksi terhadap serangan DoS.

### 2. UU ITE yang relevan  
Pasal 30 UU ITE:

Setiap orang dilarang mengakses komputer atau sistem elektronik milik orang lain dengan cara apa pun tanpa izin.

Pasal 32 UU ITE:

Setiap orang dengan sengaja dan tanpa hak atau melawan hukum mengubah, menambah, mengurangi, mentransmisikan, merusak, menghilangkan, memindahkan data elektronik milik orang lain, dapat dipidana.

### 3. Pandangan Al-Qur'an  
- Surah Al-Baqarah: 205  
Surah Al-Baqarah Ayat 205:

"Dan apabila ia berpaling (dari kamu), ia berjalan di bumi untuk mengadakan kerusakan padanya dan merusak tanaman-tanaman dan binatang ternak. Dan Allah tidak menyukai kerusakan."


### 4. Etika Cyber dan Kejujuran  
Dalam dunia cybersecurity, nilai kejujuran dan amanah sangat penting. Profesional keamanan siber harus:

Jujur dalam menganalisis sistem dan melaporkan kerentanannya.

Amanah dalam menjaga kerahasiaan data klien dan tidak menyalahgunakan akses yang dimiliki.

